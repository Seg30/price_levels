class InvalidParameterException(Exception):
    pass


class InvalidArgumentException(Exception):
    pass